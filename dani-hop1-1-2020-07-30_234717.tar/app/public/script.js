/*
  Project:   Hands-On Project 1-1
	Author:    Danielle Jackson
	Date:      September 1, 2019
	Purpose:   To demonstrate the basic structure of a web project.
*/

// create ordered list
    document.write("<ol>");
    document.write("<li>Reduce spending on non-necessities.</li>");
    document.write("<li>Use extra money to pay off debt, starting with the highest-interest credit card.</li>");
    document.write("<li>Continue paying off debts until you are debt free.</li>");
    document.write("<li>Put a fixed percent of your pay aside in savings.</li>");
    
    //Extra credit 
    document.write("<li>Learn how to become a pro in <a href='https://www.nerdwallet.com/blog/investing/what-is-a-financial-plan-how-can-i-make-one/'>financial planning.</a></li>");
    
    document.write("</ol>");
